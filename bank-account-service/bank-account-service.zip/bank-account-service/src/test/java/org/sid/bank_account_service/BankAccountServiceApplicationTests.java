package org.sid.bank_account_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAccountServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
